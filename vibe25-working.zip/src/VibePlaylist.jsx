export default function VibePlaylist() {
  return (
    <div style={{
      background: "black",
      color: "lime",
      fontSize: "2rem",
      minHeight: "100vh",
      display: "flex",
      justifyContent: "center",
      alignItems: "center"
    }}>
      <p>Hello from Vibe 25!</p>
    </div>
  );
}
